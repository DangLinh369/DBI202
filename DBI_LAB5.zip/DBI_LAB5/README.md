# Dữ liệu 

| # | File | Số dòng | PK | FK chính |
|---|------|--------|----|----------|
| 0 | `order_item.csv` | 20 | `order_item_id` | `order_id`, `product_id` |
| 1 | `location.csv` | 11 | `postal_code` | — |
| 2 | `customer_address.csv` | 15 | `address_id` | `customer_id`, `postal_code` |
| 3 | `order_item_snapshot.csv` | 20 | `order_item_id` (PK/FK, 1:1) | `order_item_id` |
| 4 | `order_group.csv` | 11 | `group_id` | `warehouse_id` |
| 5 | `order_group_order.csv` | 14 | (`group_id`,`order_id`) | `group_id`, `order_id` |
| 6 | `sync_log.csv` | 24 | `sync_id` | `business_id` |
| 7 | `warehouse_staff.csv` | 27 | `staff_id` | `warehouse_id` |
| 8 | `packaging_material.csv` | 22 | `material_id` | `business_id` |
| 9 | `fulfillment.csv` | 15 | `fulfillment_id` | `order_id`, `warehouse_id`, `assigned_staff_id` |
| 10 | `fulfillment_task.csv` | 60 | `task_id` | `fulfillment_id`, `assigned_staff_id` |
| 11 | `fulfillment_progress.csv` | 59 | `progress_id` | `fulfillment_id`, `updated_by` |
| 12 | `ai_recommendation.csv` | 14 | `recommendation_id` | `fulfillment_id`, `recommended_box_id`, `recommended_filler_id`, `approved_by` |
| 13 | `package.csv` | 12 | `package_id` | `fulfillment_id`, `recommendation_id`, `material_id` |
| 14 | `shipment.csv` | 11 | `shipment_id` | `package_id`, `managed_by` |



## Thứ tự import (cha trước, con sau)
`business → customer → location → customer_address → product → warehouse → inventory → orders → order_item → order_item_snapshot → order_group → order_group_order → sync_log → warehouse_staff → packaging_material → fulfillment → fulfillment_task → fulfillment_progress → ai_recommendation → package → shipment`

## Quy tắc thiết kế đã tuân thủ (kiểm tra tự động, 0 lỗi)
- **PK/UK** không trùng (`email` staff, `name` material, `tracking_number`...).
- **FK**: mọi FK của 14 bảng mới đều trỏ tới dòng có thật.
- **NOT NULL** đủ cột bắt buộc; cột nullable để trống đúng chỗ.
- **CHECK**: `status/priority/staff_role/shipping_status/approval_status` đúng tập giá trị trong báo cáo; `void_ratio` ∈ [0,1]; `box_quantity > 0`; `sequence > 0`; tiền/số lượng ≥ 0.
- **Nhất quán nghiệp vụ**: kho của fulfillment = kho của business sở hữu đơn; staff/approver/shipper đúng kho; vật liệu đóng gói đúng business; sản phẩm vừa thùng; mốc thời gian tăng dần; trạng thái fulfillment/shipment khớp `orders.status`; mỗi đơn đều có ít nhất 1 order item.


